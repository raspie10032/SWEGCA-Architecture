# SWEGCA confidential reviewer supplement

This package contains only the deterministic synthetic evidence-binding data and
the minimum import closure required to audit or reproduce the reported contract
evaluation. It contains no prompts, user records, model outputs, private
Rozephine experience, models, checkpoints, external datasets, repository
history, author contact details, or workstation paths.

## Data layout

- `runs/primary-development/`: 102,400 generated paired contract cases.
- `runs/heldout-confirmation/`: the consumed one-time 10,240-case confirmation.
- `validation/`: exact-schema validation receipts for both ledgers.
- `paper/swegca/scripts/`: portable evaluator; only Git metadata fallback differs.
- `provenance/original_evaluator.py`: byte-exact evaluator used by the runs.
- `src/tinylm_slicer/`: byte-exact minimum import closure.
- `configs/`: path-free primary and portable held-out configurations.
- `ARTIFACT_LINEAGE.json`: original hashes and every disclosed sanitization.
- `MANIFEST.sha256`: SHA-256 for every other package member.

The held-out split was already opened once. Re-execution can reproduce the
deterministic outcome counts but is not a new independent confirmation. Runtime,
latency, Git metadata, and output-report hashes can differ by environment.

## Environment and commands

Use Python 3.11 or newer. From this package root, install the declared NumPy and
PyTorch dependencies before running the evaluator:

```powershell
python -m pip install -r requirements.txt
```

Then run:

```powershell
$env:PYTHONPATH = (Join-Path (Get-Location) 'src')
python paper/swegca/scripts/evaluate_evidence_binding_statistics.py --config configs/swegca_evidence_binding_stress_100k_v1.json --split stress --output reviewer_outputs/primary/report.json
python paper/swegca/scripts/evaluate_evidence_binding_statistics.py --config configs/swegca_evidence_binding_statistical_evaluation_v1.portable.json --split heldout --frozen-manifest configs/swegca_evidence_binding_heldout_freeze_v1.portable.json --output reviewer_outputs/heldout/report.json
```

Compare outcome counts and integrity fields, not latency or report hashes. The
portable evaluator changes only the optional Git revision string when no Git
checkout is present; `provenance/original_evaluator.py` preserves the exact
evaluated source.
